package students.items;

public class Weed
{

}
